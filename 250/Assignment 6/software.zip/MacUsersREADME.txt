README For those of you using Macs:

The Install.bat, pretty.bat and build.bat files are meant for Windows users. 
So I've created versions for you to use;  InstallA, prettyA and buildA are the
filenames.  You may need to change the file protections first though.

   chmod 0755 InstallA
   chmod 0755 prettyA
   chmod 0755 buildA

And to run them you may need to prefix the command with the current
location;  as in.

  ./InstallA

Hope this is helpful.
P.M.J. - March 26, 2012
 
