/* Java application that uses the standard formula from Physics to compute 
** the position of a body in linear motion after a given period of time has
** passed, based upon its initial position, initial velocity, and (constant)
** rate of acceleration.
**
** Student's names: ....
*/
public class Displacement {

   public static void main(String[] args) {

      // Paste your code here from BJP4 Execise 2.1 (displacment)

   }
}
