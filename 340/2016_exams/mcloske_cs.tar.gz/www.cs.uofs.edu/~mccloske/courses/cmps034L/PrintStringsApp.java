/* Java application meant as a "wrapper" for BJP4 Self-Check 3.10: printStrings.
**
** Members of lab group: ...
*/
public class PrintStringsApp {

   public static void main(String[] args) {
      printStrings("glorp", 7);
      printStrings("ABCDEFG", 4); 
   }

   // HERE INSERT YOUR printStrings() METHOD

}
