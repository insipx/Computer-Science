/* Java application that "draws" a goofy figure with a bunch of asterisks in
** it.  The current version is a very poor solution to BJP4 Exercise 1.13
** (StarFigure) on the Practice-It website, as it lacks any evidence of 
** procedural decomposition or code redundancy avoidance having been employed
** in its design.
*/
public class StarFigures {

   public static void main(String[] args) {
      System.out.println("*****");
      System.out.println("*****");
      System.out.println(" * *");
      System.out.println("  *");
      System.out.println(" * *");
      System.out.println();
      System.out.println("*****");
      System.out.println("*****");
      System.out.println(" * *");
      System.out.println("  *");
      System.out.println(" * *");
      System.out.println("*****");
      System.out.println("*****");
      System.out.println();
      System.out.println("  *");
      System.out.println("  *");
      System.out.println("  *");
      System.out.println("*****");
      System.out.println("*****");
      System.out.println(" * *");
      System.out.println("  *");
      System.out.println(" * *");
   }

}

