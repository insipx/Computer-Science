/* Java program that prints an innocuous message.
** Author: R. McCloskey
** Date: Feb. 1, 2015
*/

public class HelloWorld {

   public static void main(String[] args) {
      System.out.println("Hello, World.");
   }
}

