/** Program (from page 31 of Reges & Stepp textbook (3rd ed.)) that draws two
**  boxes separated by a blank line.  Notice that the sections of code that
**  draw the boxes are duplicates.
*/

public class DrawBoxes {

   public static void main(String[] args) {

      System.out.println("+------+");
      System.out.println("|      |");
      System.out.println("|      |");
      System.out.println("+------+");
      System.out.println();
      System.out.println("+------+");
      System.out.println("|      |");
      System.out.println("|      |");
      System.out.println("+------+");
   }
}
