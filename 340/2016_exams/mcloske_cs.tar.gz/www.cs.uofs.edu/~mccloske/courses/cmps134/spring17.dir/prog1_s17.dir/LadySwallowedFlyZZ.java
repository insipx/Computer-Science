/* Java program that prints the lyrics of a modified version of the
** nursery rhyme "There Was an Old Lady Who Swallowed a Fly".
**
** CMPS 134  Spring 2017  Prog. Assg. #1
** Author: <your name>
** Aided by: <names of persons who provided aid>
** Known Flaws: <list of known deficiencies>
*/

public class LadySwallowedFly {

   public static void main(String[] args) {

   }

}
